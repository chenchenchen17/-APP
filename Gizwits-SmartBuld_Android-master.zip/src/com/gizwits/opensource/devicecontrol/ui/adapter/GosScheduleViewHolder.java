/**
 * 
 */
package com.gizwits.opensource.devicecontrol.ui.adapter;

import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * @author Administrator
 *
 */
public class GosScheduleViewHolder {
	public TextView tvStatus;
	public TextView tvTime;
	public TextView tvDate;
	public Button btnChecked;
	public RelativeLayout rlDelete;
}
