/**
 * 
 */
package com.gizwits.opensource.devicecontrol.ui.adapter;

/**
 * @author Administrator
 *
 */
public class GosScheduleCheckBoxListDateHolder {

	public String itemName;
	public boolean checked;

	/**
	 * @param itemName
	 * @param checked
	 */
	public GosScheduleCheckBoxListDateHolder(String itemName, boolean checked) {
		super();
		this.itemName = itemName;
		this.checked = checked;
	}

}
